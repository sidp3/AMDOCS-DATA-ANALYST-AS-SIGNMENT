# FinInsight AI — Smart Financial Data Assistant
### Amdocs Data Analyst Assignment

---

## 🚀 Quick Start (3 commands)

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 📦 Deploy to Netlify (1 minute)

```bash
npm install
npm run build
```

Then drag the `/build` folder to → **https://app.netlify.com/drop**

---

## 🌐 Deploy to Vercel

1. Push this folder to a GitHub repo
2. Go to https://vercel.com → "Import Project"
3. Select the repo → Deploy (zero config needed)

---

## 🤖 AI Assistant — API Key Setup

The AI Assistant tab calls the Anthropic Claude API.
For **local development**, it works directly via browser.

For **production deployment**, create a `.env` file:

```
REACT_APP_ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Then update `src/pages/AssistantPage.js` line with the fetch headers to add:
```js
"x-api-key": process.env.REACT_APP_ANTHROPIC_API_KEY,
"anthropic-version": "2023-06-01",
"anthropic-dangerous-direct-browser-access": "true",
```

> ⚠️ For enterprise, proxy API calls through a backend (Next.js API route / Express) to keep the key secret.

---

## 📁 Project Structure

```
fininsight/
├── public/
│   └── index.html
├── src/
│   ├── App.js              ← Root with sidebar navigation
│   ├── index.js            ← React entry point
│   ├── data.js             ← Synthetic 500-customer dataset
│   ├── colors.js           ← Design system palette
│   ├── components/
│   │   └── shared.js       ← Reusable UI (MetricCard, FilterBar, Tooltip)
│   └── pages/
│       ├── OverviewPage.js     ← Phase 3: Dashboard view 1
│       ├── RiskPage.js         ← Phase 3: Dashboard view 2
│       ├── CustomersPage.js    ← Phase 3: Dashboard view 3
│       ├── TrendsPage.js       ← Phase 3: Dashboard view 4
│       ├── AssistantPage.js    ← Phase 4: AI Chat Interface
│       └── InsightsPage.js     ← Phase 5: Executive Summary
├── package.json
└── README.md
```

---

## 📋 Assignment Coverage

| Phase | Requirement | Status |
|-------|-------------|--------|
| 1 | Dataset selection (Credit Risk) | ✅ |
| 2 | Data preparation & EDA | ✅ |
| 3 | Interactive dashboard (4 views, filters) | ✅ |
| 4 | AI Assistant with NL querying | ✅ |
| 5 | Executive summary + recommendations | ✅ |
| Bonus | Enterprise roadmap | ✅ |

---

Built with React · Recharts · Claude API
