import React, { useState } from "react";
import { CUSTOMERS } from "./data";
import { FilterBar } from "./components/shared";
import C from "./colors";

import OverviewPage   from "./pages/OverviewPage";
import RiskPage       from "./pages/RiskPage";
import CustomersPage  from "./pages/CustomersPage";
import TrendsPage     from "./pages/TrendsPage";
import AssistantPage  from "./pages/AssistantPage";
import InsightsPage   from "./pages/InsightsPage";

const NAV = [
  { id: "overview",  icon: "📊", label: "Overview" },
  { id: "risk",      icon: "🛡️", label: "Risk Analysis" },
  { id: "customers", icon: "👥", label: "Customer Segments" },
  { id: "trends",    icon: "📈", label: "Trends" },
  { id: "assistant", icon: "🤖", label: "AI Assistant" },
  { id: "insights",  icon: "💡", label: "Executive Summary" },
];

const PAGES = {
  overview:   OverviewPage,
  risk:       RiskPage,
  customers:  CustomersPage,
  trends:     TrendsPage,
  assistant:  AssistantPage,
  insights:   InsightsPage,
};

const NO_FILTER_PAGES = new Set(["assistant", "insights"]);

export default function App() {
  const [page, setPage]       = useState("overview");
  const [filters, setFilters] = useState({ region: "All", segment: "All" });

  const Page       = PAGES[page];
  const showFilter = !NO_FILTER_PAGES.has(page);

  const filteredCount = CUSTOMERS.filter(
    c =>
      (filters.region === "All" || c.region === filters.region) &&
      (filters.segment === "All" || c.segment === filters.segment)
  ).length;

  return (
    <div style={{ display: "flex", height: "100vh", background: "#f7f7fc", fontFamily: "'Inter', system-ui, sans-serif" }}>
      {/* ── SIDEBAR ────────────────────────────────────────────────── */}
      <div style={{ width: 220, background: "#1a1a2e", padding: "24px 0", display: "flex", flexDirection: "column", flexShrink: 0 }}>
        {/* Logo */}
        <div style={{ padding: "0 20px 24px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 8, background: C.purple,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17,
            }}>
              📊
            </div>
            <div>
              <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: "white" }}>FinInsight AI</p>
              <p style={{ margin: 0, fontSize: 10, color: "rgba(255,255,255,0.38)" }}>Amdocs · Data Analyst</p>
            </div>
          </div>
        </div>

        {/* Nav links */}
        <div style={{ padding: "16px 12px", flex: 1 }}>
          {NAV.map(n => (
            <button
              key={n.id}
              onClick={() => setPage(n.id)}
              style={{
                display: "flex", alignItems: "center", gap: 10,
                width: "100%", padding: "10px 12px", borderRadius: 8,
                border: "none", cursor: "pointer", marginBottom: 2, textAlign: "left",
                background: page === n.id ? `${C.purple}38` : "transparent",
                color:      page === n.id ? "white" : "rgba(255,255,255,0.48)",
                fontWeight: page === n.id ? 600 : 400,
                fontSize: 13,
                borderLeft: page === n.id ? `2px solid ${C.purple}` : "2px solid transparent",
                fontFamily: "inherit",
                transition: "background 0.15s, color 0.15s",
              }}
            >
              <span style={{ fontSize: 16 }}>{n.icon}</span>
              {n.label}
            </button>
          ))}
        </div>

        {/* Footer */}
        <div style={{ padding: "12px 20px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <p style={{ margin: 0, fontSize: 10, color: "rgba(255,255,255,0.22)", lineHeight: 1.6 }}>
            Synthetic dataset · 500 customers<br />
            Credit Risk · Amdocs Assignment
          </p>
        </div>
      </div>

      {/* ── MAIN CONTENT ───────────────────────────────────────────── */}
      <div style={{ flex: 1, overflowY: "auto", padding: "28px 28px 48px" }}>
        {showFilter && (
          <FilterBar filters={filters} setFilters={setFilters} total={filteredCount} />
        )}
        <Page filters={filters} />
      </div>
    </div>
  );
}
