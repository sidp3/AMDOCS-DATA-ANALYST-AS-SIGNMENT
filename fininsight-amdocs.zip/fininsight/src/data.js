// ─── SYNTHETIC DATASET ────────────────────────────────────────────────────────
const rand = (a, b) => Math.random() * (b - a) + a;
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

export const CUSTOMERS = Array.from({ length: 500 }, (_, i) => {
  const age = Math.floor(rand(22, 70));
  const income = Math.floor(rand(20000, 150000));
  const creditScore = Math.floor(rand(300, 850));
  const loanAmount = Math.floor(rand(5000, 80000));
  const tenure = Math.floor(rand(1, 120));
  const numProducts = Math.floor(rand(1, 5));
  const balance = Math.floor(rand(0, 200000));
  const missedPayments = Math.floor(rand(0, 6));
  const region = pick(["North", "South", "East", "West", "Central"]);
  const segment =
    income > 100000 ? "High Value" : income > 60000 ? "Mid Value" : "Low Value";
  const riskScore = Math.max(
    0,
    Math.min(
      100,
      100 -
        creditScore / 8.5 +
        missedPayments * 8 -
        income / 3000 +
        loanAmount / 1200
    )
  );
  const defaulted =
    riskScore > 65 || (creditScore < 500 && missedPayments > 3) ? 1 : 0;
  const month = pick([
    "Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec",
  ]);
  const year = pick([2022, 2023, 2024]);
  return {
    id: i + 1, age, income, creditScore, loanAmount, tenure,
    numProducts, balance, missedPayments, region, segment,
    riskScore: Math.round(riskScore), defaulted, month, year,
  };
});

export const MONTHLY_TRENDS = (() => {
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return months.map((m, i) => ({
    month: m,
    defaults: Math.floor(20 + Math.sin(i * 0.5) * 8 + Math.random() * 5),
    newLoans: Math.floor(80 + Math.cos(i * 0.4) * 15 + Math.random() * 10),
    revenue: Math.floor(450000 + Math.sin(i * 0.6) * 50000 + Math.random() * 30000),
    avgRisk: Math.floor(42 + Math.sin(i * 0.3) * 5 + Math.random() * 4),
  }));
})();

export const avg = arr =>
  arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

export const fmt = (n, style = "decimal", min = 0) =>
  new Intl.NumberFormat("en-IN", {
    style,
    minimumFractionDigits: min,
    maximumFractionDigits: min,
    ...(style === "currency"
      ? { currency: "USD", notation: "compact" }
      : {}),
  }).format(n);
