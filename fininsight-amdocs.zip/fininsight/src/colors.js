// ─── COLOR PALETTE ────────────────────────────────────────────────────────────
const C = {
  purple:      "#7F77DD",
  purpleLight: "#EEEDFE",
  purpleDark:  "#3C3489",
  teal:        "#1D9E75",
  tealLight:   "#E1F5EE",
  tealDark:    "#085041",
  coral:       "#D85A30",
  coralLight:  "#FAECE7",
  coralDark:   "#993C1D",
  amber:       "#BA7517",
  amberLight:  "#FAEEDA",
  amberDark:   "#854F0B",
  blue:        "#378ADD",
  blueLight:   "#E6F1FB",
  blueDark:    "#0C447C",
  gray:        "#888780",
  grayLight:   "#F1EFE8",
  grayDark:    "#444441",
  red:         "#E24B4A",
  redLight:    "#FCEBEB",
  green:       "#639922",
  greenLight:  "#EAF3DE",
};

export default C;
