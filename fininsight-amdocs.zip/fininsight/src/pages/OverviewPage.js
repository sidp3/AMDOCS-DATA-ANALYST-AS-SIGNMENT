import React, { useMemo } from "react";
import {
  BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { CUSTOMERS, MONTHLY_TRENDS, avg, fmt } from "../data";
import { MetricCard, CustomTooltip } from "../components/shared";
import C from "../colors";

export default function OverviewPage({ filters }) {
  const data = useMemo(
    () =>
      CUSTOMERS.filter(
        c =>
          (filters.region === "All" || c.region === filters.region) &&
          (filters.segment === "All" || c.segment === filters.segment)
      ),
    [filters]
  );

  const totalLoan = data.reduce((s, c) => s + c.loanAmount, 0);
  const defaultRate = (
    (data.filter(c => c.defaulted).length / data.length) *
    100
  ).toFixed(1);
  const avgCredit = Math.round(avg(data.map(c => c.creditScore)));
  const highRisk = data.filter(c => c.riskScore > 65).length;

  const regionData = ["North", "South", "East", "West", "Central"].map(r => ({
    region: r,
    customers: data.filter(c => c.region === r).length,
    avgLoan: Math.round(avg(data.filter(c => c.region === r).map(c => c.loanAmount))),
    defaults: data.filter(c => c.region === r && c.defaulted).length,
  }));

  const riskBuckets = [
    { name: "Low (0–30)", value: data.filter(c => c.riskScore <= 30).length, color: C.teal },
    { name: "Medium (31–65)", value: data.filter(c => c.riskScore > 30 && c.riskScore <= 65).length, color: C.amber },
    { name: "High (66–100)", value: data.filter(c => c.riskScore > 65).length, color: C.coral },
  ];

  return (
    <div>
      <h2 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#1a1a2e" }}>
        Portfolio Overview
      </h2>
      <p style={{ margin: "0 0 20px", color: "#888", fontSize: 14 }}>
        Credit risk analysis across {data.length} customers
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, marginBottom: 24 }}>
        <MetricCard label="Total Portfolio" value={"$" + fmt(totalLoan / 1e6, "decimal", 1) + "M"} sub="Loan book size" color={C.purple} icon="💰" />
        <MetricCard label="Default Rate" value={defaultRate + "%"} sub={data.filter(c => c.defaulted).length + " customers defaulted"} color={C.coral} icon="⚠️" />
        <MetricCard label="Avg Credit Score" value={avgCredit} sub={avgCredit > 650 ? "Healthy portfolio" : "Needs attention"} color={C.teal} icon="📋" />
        <MetricCard label="High Risk" value={highRisk} sub={((highRisk / data.length) * 100).toFixed(1) + "% of portfolio"} color={C.amber} icon="🛡️" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 600 }}>Loan Volume by Region</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={regionData} barSize={32}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="region" tick={{ fontSize: 12, fill: "#888" }} />
              <YAxis tick={{ fontSize: 12, fill: "#888" }} tickFormatter={v => "$" + Math.round(v / 1000) + "K"} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="avgLoan" name="Avg Loan" fill={C.purple} radius={[4, 4, 0, 0]} />
              <Bar dataKey="defaults" name="Defaults" fill={C.coral} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 600 }}>Risk Distribution</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={riskBuckets} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={3}>
                {riskBuckets.map((b, i) => <Cell key={i} fill={b.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
            {riskBuckets.map(b => (
              <div key={b.name} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "#555" }}>
                <span style={{ width: 10, height: 10, borderRadius: 2, background: b.color, display: "inline-block" }} />
                {b.name}: <b style={{ marginLeft: 2 }}>{b.value}</b>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8", marginTop: 16 }}>
        <h3 style={{ margin: "0 0 12px", fontSize: 15, fontWeight: 600 }}>Monthly Revenue Trend</h3>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={MONTHLY_TRENDS}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={C.purple} stopOpacity={0.15} />
                <stop offset="95%" stopColor={C.purple} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#888" }} />
            <YAxis tick={{ fontSize: 12, fill: "#888" }} tickFormatter={v => "$" + Math.round(v / 1000) + "K"} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="revenue" name="Revenue ($)" stroke={C.purple} fill="url(#revGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
