import React from "react";
import {
  LineChart, Line, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { MONTHLY_TRENDS } from "../data";
import { CustomTooltip } from "../components/shared";
import C from "../colors";

export default function TrendsPage() {
  return (
    <div>
      <h2 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#1a1a2e" }}>
        Trends &amp; Patterns
      </h2>
      <p style={{ margin: "0 0 20px", color: "#888", fontSize: 14 }}>
        Monthly dynamics across key performance indicators
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 600 }}>
            Monthly Defaults vs. New Loans
          </h3>
          <p style={{ margin: "0 0 12px", fontSize: 12, color: "#888" }}>
            Peaks in new loans tend to precede default spikes by ~2 months
          </p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={MONTHLY_TRENDS}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#888" }} />
              <YAxis tick={{ fontSize: 12, fill: "#888" }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line type="monotone" dataKey="newLoans" name="New Loans" stroke={C.purple} strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="defaults" name="Defaults" stroke={C.coral} strokeWidth={2} strokeDasharray="5 5" dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 600 }}>
            Average Portfolio Risk Over Time
          </h3>
          <p style={{ margin: "0 0 12px", fontSize: 12, color: "#888" }}>
            Risk score fluctuates — Q2 spike warrants deeper investigation
          </p>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={MONTHLY_TRENDS}>
              <defs>
                <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.amber} stopOpacity={0.2} />
                  <stop offset="95%" stopColor={C.amber} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#888" }} />
              <YAxis tick={{ fontSize: 12, fill: "#888" }} domain={[30, 55]} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="avgRisk" name="Avg Risk Score" stroke={C.amber} fill="url(#riskGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
        <h3 style={{ margin: "0 0 12px", fontSize: 15, fontWeight: 600 }}>
          Revenue Trend with Loan Origination Volume
        </h3>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={MONTHLY_TRENDS}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
            <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#888" }} />
            <YAxis yAxisId="left"  tick={{ fontSize: 12, fill: "#888" }} tickFormatter={v => "$" + Math.round(v / 1000) + "K"} />
            <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12, fill: "#888" }} />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Line yAxisId="left"  type="monotone" dataKey="revenue"  name="Revenue ($)"  stroke={C.teal} strokeWidth={2.5} />
            <Line yAxisId="right" type="monotone" dataKey="newLoans" name="New Loans (#)" stroke={C.blue} strokeWidth={2} strokeDasharray="4 3" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div style={{ background: C.purpleLight, borderRadius: 12, padding: 16, marginTop: 16, border: `1px solid ${C.purple}33` }}>
        <h4 style={{ margin: "0 0 8px", fontSize: 14, fontWeight: 700, color: C.purpleDark }}>
          📊 Analyst Note — Limitations &amp; Biases
        </h4>
        <p style={{ margin: 0, fontSize: 13, color: C.purpleDark, lineHeight: 1.6 }}>
          This dataset is synthetically generated for demonstration purposes. Real-world data would show seasonal spikes
          (Q4 holiday lending) and macroeconomic shocks. The current model assumes static risk scores — in practice, risk
          should be recalculated monthly. Survivorship bias may exist if defaulted customers were removed from panels.
          Geographic analysis is limited to 5 regions without postal-code granularity.
        </p>
      </div>
    </div>
  );
}
