import React, { useMemo } from "react";
import {
  BarChart, Bar, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { CUSTOMERS, avg } from "../data";
import { CustomTooltip } from "../components/shared";
import C from "../colors";

export default function CustomersPage({ filters }) {
  const data = useMemo(
    () =>
      CUSTOMERS.filter(
        c =>
          (filters.region === "All" || c.region === filters.region) &&
          (filters.segment === "All" || c.segment === filters.segment)
      ),
    [filters]
  );

  const segmentStats = ["High Value", "Mid Value", "Low Value"].map(seg => {
    const g = data.filter(c => c.segment === seg);
    return {
      seg,
      count: g.length,
      avgIncome: Math.round(avg(g.map(c => c.income))),
      avgLoan: Math.round(avg(g.map(c => c.loanAmount))),
      avgCredit: Math.round(avg(g.map(c => c.creditScore))),
      defaultRate: +(g.filter(c => c.defaulted).length / g.length * 100).toFixed(1),
      color: seg === "High Value" ? C.purple : seg === "Mid Value" ? C.blue : C.gray,
    };
  });

  const incomeVsLoan = data.slice(0, 150).map(c => ({
    income: Math.round(c.income / 1000),
    loan: Math.round(c.loanAmount / 1000),
    segment: c.segment,
  }));

  const ageGroups = [
    { age: "22–30", min: 22, max: 30 },
    { age: "31–40", min: 31, max: 40 },
    { age: "41–50", min: 41, max: 50 },
    { age: "51–60", min: 51, max: 60 },
    { age: "61+", min: 61, max: 200 },
  ].map(g => ({
    age: g.age,
    high: data.filter(c => c.age >= g.min && c.age <= g.max && c.segment === "High Value").length,
    mid:  data.filter(c => c.age >= g.min && c.age <= g.max && c.segment === "Mid Value").length,
    low:  data.filter(c => c.age >= g.min && c.age <= g.max && c.segment === "Low Value").length,
  }));

  return (
    <div>
      <h2 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#1a1a2e" }}>
        Customer Segments
      </h2>
      <p style={{ margin: "0 0 20px", color: "#888", fontSize: 14 }}>
        Behavioral segmentation and value analysis
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginBottom: 20 }}>
        {segmentStats.map(s => (
          <div key={s.seg} style={{
            background: "white", borderRadius: 12, padding: 20,
            border: `2px solid ${s.color}22`,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: s.color, display: "inline-block" }} />
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#1a1a2e" }}>{s.seg}</h3>
              <span style={{
                marginLeft: "auto", background: s.color + "20", color: s.color,
                fontSize: 12, fontWeight: 600, padding: "2px 8px", borderRadius: 20,
              }}>
                {s.count} customers
              </span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {[
                ["Avg Income", "$" + s.avgIncome.toLocaleString()],
                ["Avg Loan",   "$" + s.avgLoan.toLocaleString()],
                ["Credit Score", s.avgCredit],
                ["Default Rate", s.defaultRate + "%"],
              ].map(([k, v]) => (
                <div key={k} style={{ background: "#fafafa", borderRadius: 8, padding: "8px 10px" }}>
                  <p style={{ margin: 0, fontSize: 11, color: "#999" }}>{k}</p>
                  <p style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "#1a1a2e" }}>{v}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 600 }}>Income vs. Loan Amount</h3>
          <p style={{ margin: "0 0 12px", fontSize: 12, color: "#888" }}>By segment (sample of 150)</p>
          <ResponsiveContainer width="100%" height={230}>
            <ScatterChart margin={{ bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="income" name="Income (K)" tick={{ fontSize: 11, fill: "#888" }}
                label={{ value: "Income ($K)", position: "insideBottom", offset: -10, fontSize: 12, fill: "#888" }} />
              <YAxis dataKey="loan" name="Loan (K)" tick={{ fontSize: 11, fill: "#888" }} />
              <Tooltip content={({ active, payload }) => {
                if (!active || !payload?.[0]) return null;
                const d = payload[0].payload;
                return (
                  <div style={{ background: "white", border: "1px solid #eee", borderRadius: 8, padding: "6px 10px", fontSize: 12 }}>
                    <p style={{ margin: 0 }}>Income: <b>${d.income}K</b></p>
                    <p style={{ margin: 0 }}>Loan: <b>${d.loan}K</b></p>
                    <p style={{ margin: 0, color: "#888" }}>{d.segment}</p>
                  </div>
                );
              }} />
              {[
                { seg: "High Value", color: C.purple },
                { seg: "Mid Value",  color: C.blue },
                { seg: "Low Value",  color: C.gray },
              ].map(({ seg, color }) => (
                <Scatter key={seg} data={incomeVsLoan.filter(d => d.segment === seg)} fill={color} fillOpacity={0.5} name={seg} />
              ))}
            </ScatterChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 12px", fontSize: 15, fontWeight: 600 }}>Age Distribution by Segment</h3>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={ageGroups} barSize={16}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="age" tick={{ fontSize: 12, fill: "#888" }} />
              <YAxis tick={{ fontSize: 12, fill: "#888" }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="high" name="High Value" fill={C.purple} stackId="a" />
              <Bar dataKey="mid"  name="Mid Value"  fill={C.blue}   stackId="a" />
              <Bar dataKey="low"  name="Low Value"  fill={C.gray}   stackId="a" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
