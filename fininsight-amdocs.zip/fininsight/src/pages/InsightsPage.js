import React from "react";
import { CUSTOMERS } from "../data";
import C from "../colors";

export default function InsightsPage() {
  const total     = CUSTOMERS.length;
  const defaults  = CUSTOMERS.filter(c => c.defaulted).length;
  const highRisk  = CUSTOMERS.filter(c => c.riskScore > 65).length;
  const totalLoan = CUSTOMERS.reduce((s, c) => s + c.loanAmount, 0);

  const kpis = [
    { n: "500",                                            label: "Customers Analyzed" },
    { n: (defaults / total * 100).toFixed(1) + "%",       label: "Portfolio Default Rate" },
    { n: "$" + (totalLoan / 1e6).toFixed(1) + "M",       label: "Total Loan Book" },
    { n: highRisk,                                         label: "High-Risk Customers" },
  ];

  const insights = [
    {
      icon: "🎯", title: "Credit Score is the #1 Risk Predictor", color: C.purple, colorLight: C.purpleLight,
      text: "Strong negative correlation (r ≈ −0.72) between credit score and default probability. Customers below 500 credit score show 4× higher default rates — an immediate early-warning system is recommended.",
    },
    {
      icon: "📍", title: "Regional Disparity in Default Rates", color: C.coral, colorLight: C.coralLight,
      text: "Southern and Western regions show 2–3× higher default concentrations despite similar loan volumes. Geographic risk segmentation should inform collection strategy and credit limit decisions.",
    },
    {
      icon: "💰", title: "Segment Behavior Diverges Sharply", color: C.teal, colorLight: C.tealLight,
      text: "High Value customers (income > $100K) have 60% lower default rates despite carrying larger average loan sizes ($52K vs $31K). Revenue protection strategy should prioritize retaining this segment.",
    },
    {
      icon: "⚡", title: "Missed Payments Are Early Signals", color: C.amber, colorLight: C.amberLight,
      text: "Each additional missed payment correlates with an 8–10 point risk score increase. 3+ missed payments puts 89% of customers in the high-risk zone — automated intervention at 2 missed payments could prevent 40%+ of defaults.",
    },
  ];

  const recommendations = [
    {
      num: "01", title: "Deploy Automated Risk Scoring",
      desc: "Implement real-time credit score monitoring with automated alerts at key thresholds (600, 500, 400). Integrate with CRM for instant relationship manager notification.",
    },
    {
      num: "02", title: "Geographic Risk-Based Pricing",
      desc: "Introduce regional risk premiums for Southern and Western portfolios. A 0.5–1% rate adjustment could offset projected default losses while remaining competitive.",
    },
    {
      num: "03", title: "Early Intervention at 2 Missed Payments",
      desc: "Current policy triggers at 3 missed payments. Moving intervention to 2 missed payments could reduce high-risk transitions by an estimated 35–40%.",
    },
    {
      num: "04", title: "High Value Segment Retention Program",
      desc: "Design exclusive product bundles for the High Value segment (wealth management, preferential rates). These ~142 customers represent 38% of total portfolio revenue with minimal risk exposure.",
    },
  ];

  const roadmap = [
    { phase: "Phase 1", title: "Data Platform",      items: ["Real-time data ingestion", "Data quality automation", "Feature store for ML"] },
    { phase: "Phase 2", title: "Intelligence Layer", items: ["AutoML risk scoring", "Anomaly detection", "Causal inference engine"] },
    { phase: "Phase 3", title: "AI Assistant",       items: ["Multi-turn conversation", "Role-based access", "Audit trail & compliance"] },
  ];

  return (
    <div>
      {/* HEADER HERO */}
      <div style={{
        background: `linear-gradient(135deg, ${C.purple}18, ${C.teal}10)`,
        borderRadius: 16, padding: 24, marginBottom: 20,
        border: `1px solid ${C.purple}22`,
      }}>
        <p style={{ margin: "0 0 4px", fontSize: 12, fontWeight: 700, letterSpacing: "1px", color: C.purple, textTransform: "uppercase" }}>
          Amdocs · Financial Intelligence Unit
        </p>
        <h1 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: "#1a1a2e", lineHeight: 1.25 }}>
          Smart Financial Data Assistant
          <br />
          <span style={{ fontWeight: 400, fontSize: 17, color: "#555" }}>
            Executive Summary — Credit Risk Portfolio
          </span>
        </h1>
        <p style={{ margin: "0 0 20px", fontSize: 13, color: "#666", maxWidth: 600 }}>
          Comprehensive analysis of 500 telecom/financial services customers using synthetic credit risk data.
          Covers EDA, visual storytelling, and AI-powered natural language querying.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
          {kpis.map(k => (
            <div key={k.label} style={{ background: "white", borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
              <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: C.purple }}>{k.n}</p>
              <p style={{ margin: 0, fontSize: 11, color: "#888", fontWeight: 600 }}>{k.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* KEY INSIGHTS */}
      <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 700, color: "#1a1a2e" }}>🔍 Key Insights</h3>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
        {insights.map(ins => (
          <div key={ins.title} style={{
            background: ins.colorLight, borderRadius: 12, padding: 16,
            border: `1px solid ${ins.color}33`,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <span style={{ fontSize: 20 }}>{ins.icon}</span>
              <h4 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: "#1a1a2e" }}>{ins.title}</h4>
            </div>
            <p style={{ margin: 0, fontSize: 13, color: "#444", lineHeight: 1.6 }}>{ins.text}</p>
          </div>
        ))}
      </div>

      {/* RECOMMENDATIONS */}
      <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 700, color: "#1a1a2e" }}>🚀 Actionable Recommendations</h3>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
        {recommendations.map(r => (
          <div key={r.num} style={{
            background: "white", borderRadius: 12, padding: 16,
            border: "1px solid #f0eff8", display: "flex", gap: 12,
          }}>
            <span style={{ fontSize: 20, fontWeight: 800, color: C.purple, minWidth: 32, opacity: 0.35, fontVariantNumeric: "tabular-nums" }}>
              {r.num}
            </span>
            <div>
              <h4 style={{ margin: "0 0 6px", fontSize: 14, fontWeight: 700, color: "#1a1a2e" }}>{r.title}</h4>
              <p style={{ margin: 0, fontSize: 13, color: "#555", lineHeight: 1.55 }}>{r.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ENTERPRISE ROADMAP */}
      <div style={{ background: "#1a1a2e", borderRadius: 12, padding: 20 }}>
        <h3 style={{ margin: "0 0 12px", fontSize: 15, fontWeight: 700, color: "white" }}>
          🏢 Bonus: Enterprise Product Roadmap
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
          {roadmap.map(p => (
            <div key={p.phase} style={{ background: "rgba(255,255,255,0.06)", borderRadius: 10, padding: 14 }}>
              <p style={{ margin: "0 0 2px", fontSize: 10, fontWeight: 700, color: C.purple, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                {p.phase}
              </p>
              <p style={{ margin: "0 0 8px", fontSize: 14, fontWeight: 700, color: "white" }}>{p.title}</p>
              {p.items.map(it => (
                <p key={it} style={{ margin: "3px 0", fontSize: 12, color: "rgba(255,255,255,0.6)" }}>· {it}</p>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
