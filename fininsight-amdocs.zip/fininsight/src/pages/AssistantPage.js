import React, { useState, useEffect, useRef } from "react";
import { CUSTOMERS, avg } from "../data";
import C from "../colors";

function buildSystemPrompt() {
  const total = CUSTOMERS.length;
  const defaults = CUSTOMERS.filter(c => c.defaulted).length;
  const defaultRate = (defaults / total * 100).toFixed(2);
  const avgCredit = Math.round(avg(CUSTOMERS.map(c => c.creditScore)));
  const avgLoan   = Math.round(avg(CUSTOMERS.map(c => c.loanAmount)));
  const avgIncome = Math.round(avg(CUSTOMERS.map(c => c.income)));
  const highRisk  = CUSTOMERS.filter(c => c.riskScore > 65).length;
  const totalLoan = CUSTOMERS.reduce((s, c) => s + c.loanAmount, 0);

  const regionStats = ["North","South","East","West","Central"].map(r => {
    const g = CUSTOMERS.filter(c => c.region === r);
    return `${r}: ${g.length} customers, ${(g.filter(c=>c.defaulted).length/g.length*100).toFixed(1)}% default rate, avg credit ${Math.round(avg(g.map(c=>c.creditScore)))}`;
  }).join("; ");

  const segStats = ["High Value","Mid Value","Low Value"].map(s => {
    const g = CUSTOMERS.filter(c => c.segment === s);
    return `${s}: ${g.length} customers, avg income $${Math.round(avg(g.map(c=>c.income))).toLocaleString()}, ${(g.filter(c=>c.defaulted).length/g.length*100).toFixed(1)}% default rate`;
  }).join("; ");

  return `You are a Smart Financial Data Assistant for Amdocs, analyzing a credit risk dataset of ${total} telecom/financial services customers.

DATASET SUMMARY (use ONLY this data — do NOT invent numbers):
- Total customers: ${total}
- Total loan portfolio: $${(totalLoan/1e6).toFixed(2)}M
- Default rate: ${defaultRate}% (${defaults} customers)
- Average credit score: ${avgCredit}
- Average loan amount: $${avgLoan.toLocaleString()}
- Average income: $${avgIncome.toLocaleString()}
- High-risk customers (risk score > 65): ${highRisk} (${(highRisk/total*100).toFixed(1)}%)

REGION BREAKDOWN: ${regionStats}
SEGMENT BREAKDOWN: ${segStats}

KEY CORRELATIONS:
- Credit score and risk: strong negative correlation (r ≈ −0.72)
- Each missed payment adds ~8–10 risk points
- Customers with credit < 500 have ~4× higher default rates
- High Value segment customers have 60% lower default rates than Low Value

MONTHLY TRENDS: Revenue ranges $420K–$510K, new loans 65–95/month, defaults 15–30/month.

RESPONSE RULES:
1. Always cite which data you used
2. Give structured, business-friendly answers with bullet points for complex queries
3. If a question cannot be answered from this data, say so clearly and explain why
4. For ambiguous questions, state your interpretation before answering
5. Provide actionable recommendations where relevant
6. Keep responses concise but insightful`;
}

const EXAMPLES = [
  "What is the overall default rate and which region performs worst?",
  "Compare High Value vs Low Value customers across key metrics",
  "Which segment should we prioritize for risk intervention?",
  "What revenue trend patterns do you see and what's driving them?",
];

const FAILURES = [
  { q: "What will the default rate be next quarter?", why: "No predictive model — only historical data is available" },
  { q: "Who is customer #42 and what is their name?", why: "Dataset has no PII — only anonymized attributes" },
  { q: "How does our portfolio compare to industry benchmarks?", why: "No external benchmark data is in scope" },
];

export default function AssistantPage() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      text: "Hello! I'm your Smart Financial Assistant. Ask me anything about the credit portfolio — risk patterns, customer segments, default rates, or revenue trends.\n\nTry: \"What is the average default rate?\" or \"Which region has the highest risk?\"",
    },
  ]);
  const [input, setInput]   = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setLoading(true);
    try {
      const history = messages.map(m => ({ role: m.role, content: m.text }));
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: buildSystemPrompt(),
          messages: [...history, { role: "user", content: userMsg }],
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Sorry, I couldn't process that. Please try again.";
      setMessages(prev => [...prev, { role: "assistant", text: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", text: "⚠️ Connection error. Check your network and API key, then try again." }]);
    }
    setLoading(false);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 16, height: "calc(100vh - 140px)", minHeight: 500 }}>
      {/* CHAT WINDOW */}
      <div style={{ background: "white", borderRadius: 12, border: "1px solid #f0eff8", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #f5f5f5" }}>
          <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1a1a2e" }}>🤖 Smart Financial Assistant</h3>
          <p style={{ margin: "2px 0 0", fontSize: 12, color: "#888" }}>Powered by Claude · Grounded in your 500-customer dataset</p>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 12 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
              <div style={{
                maxWidth: "80%", padding: "10px 14px", fontSize: 14, lineHeight: 1.55,
                whiteSpace: "pre-wrap", wordBreak: "break-word",
                borderRadius: m.role === "user" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                background: m.role === "user" ? C.purple : "#f8f8fd",
                color: m.role === "user" ? "white" : "#1a1a2e",
              }}>
                {m.text}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", gap: 5, padding: "10px 14px", background: "#f8f8fd", borderRadius: "16px 16px 16px 4px", width: "fit-content" }}>
              {[0, 1, 2].map(i => (
                <span key={i} style={{
                  width: 8, height: 8, borderRadius: "50%", background: C.purple,
                  display: "inline-block", animation: `bounce 1s ease ${i * 0.2}s infinite`,
                }} />
              ))}
            </div>
          )}
          <div ref={endRef} />
        </div>

        <div style={{ padding: "12px 16px", borderTop: "1px solid #f5f5f5", display: "flex", gap: 8 }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendMessage()}
            placeholder="Ask about defaults, risk, segments, revenue..."
            style={{ flex: 1, padding: "10px 14px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, outline: "none", fontFamily: "inherit" }}
          />
          <button
            onClick={sendMessage}
            disabled={loading || !input.trim()}
            style={{
              padding: "10px 20px", background: C.purple, color: "white", border: "none",
              borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer",
              opacity: loading || !input.trim() ? 0.5 : 1,
            }}
          >
            Send
          </button>
        </div>
      </div>

      {/* SIDEBAR */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12, overflowY: "auto" }}>
        <div style={{ background: "white", borderRadius: 12, padding: 16, border: "1px solid #f0eff8" }}>
          <h4 style={{ margin: "0 0 10px", fontSize: 13, fontWeight: 700, color: "#1a1a2e" }}>💬 Try these questions</h4>
          {EXAMPLES.map((ex, i) => (
            <button key={i} onClick={() => setInput(ex)} style={{
              display: "block", width: "100%", textAlign: "left", padding: "8px 10px", marginBottom: 6,
              background: C.purpleLight, border: "none", borderRadius: 8,
              fontSize: 12, color: C.purpleDark, cursor: "pointer", lineHeight: 1.4, fontFamily: "inherit",
            }}>
              {ex}
            </button>
          ))}
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 16, border: "1px solid #f0eff8" }}>
          <h4 style={{ margin: "0 0 10px", fontSize: 13, fontWeight: 700, color: C.coralDark }}>⚠️ Known Limitations</h4>
          {FAILURES.map((f, i) => (
            <div key={i} style={{ background: C.coralLight, borderRadius: 8, padding: "8px 10px", marginBottom: 6 }}>
              <p style={{ margin: "0 0 2px", fontSize: 12, fontWeight: 600, color: C.coralDark }}>❌ "{f.q}"</p>
              <p style={{ margin: 0, fontSize: 11, color: C.coral }}>{f.why}</p>
            </div>
          ))}
        </div>

        <div style={{ background: C.tealLight, borderRadius: 12, padding: 16, border: `1px solid ${C.teal}33` }}>
          <h4 style={{ margin: "0 0 8px", fontSize: 13, fontWeight: 700, color: C.tealDark }}>✅ Questions it answers well</h4>
          {[
            "Summary aggregations (avg, total, rate)",
            "Segment comparisons and rankings",
            "Risk driver explanations",
          ].map(q => (
            <p key={q} style={{ margin: "4px 0", fontSize: 12, color: C.tealDark }}>· {q}</p>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50%       { transform: translateY(-5px); }
        }
      `}</style>
    </div>
  );
}
