import React, { useMemo } from "react";
import {
  BarChart, Bar, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { CUSTOMERS, avg } from "../data";
import { CustomTooltip } from "../components/shared";
import C from "../colors";

export default function RiskPage({ filters }) {
  const data = useMemo(
    () =>
      CUSTOMERS.filter(
        c =>
          (filters.region === "All" || c.region === filters.region) &&
          (filters.segment === "All" || c.segment === filters.segment)
      ),
    [filters]
  );

  const scatterData = data.slice(0, 200).map(c => ({
    x: c.creditScore,
    y: c.riskScore,
    defaulted: c.defaulted,
  }));

  const riskByMissed = Array.from({ length: 7 }, (_, i) => ({
    missed: i,
    avgRisk: Math.round(avg(data.filter(c => c.missedPayments === i).map(c => c.riskScore))),
    count: data.filter(c => c.missedPayments === i).length,
  })).filter(r => r.count > 0);

  const creditBuckets = [
    { range: "300–500", label: "Poor" },
    { range: "500–600", label: "Fair" },
    { range: "600–700", label: "Good" },
    { range: "700–800", label: "Very Good" },
    { range: "800–850", label: "Excellent" },
  ].map(b => {
    const [lo, hi] = b.range.split("–").map(Number);
    const group = data.filter(c => c.creditScore >= lo && c.creditScore < hi);
    return {
      ...b,
      count: group.length,
      defaultRate: +(group.filter(c => c.defaulted).length / group.length * 100).toFixed(1),
    };
  });

  return (
    <div>
      <h2 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, color: "#1a1a2e" }}>
        Risk Analysis
      </h2>
      <p style={{ margin: "0 0 20px", color: "#888", fontSize: 14 }}>
        Deep dive into credit risk drivers and correlations
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 600 }}>Credit Score vs. Risk Score</h3>
          <p style={{ margin: "0 0 12px", fontSize: 12, color: "#888" }}>
            Strong negative correlation (r ≈ −0.72) — higher credit score = lower risk
          </p>
          <ResponsiveContainer width="100%" height={230}>
            <ScatterChart margin={{ bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="x" name="Credit Score" tick={{ fontSize: 11, fill: "#888" }}
                label={{ value: "Credit Score", position: "insideBottom", offset: -10, fontSize: 12, fill: "#888" }} />
              <YAxis dataKey="y" name="Risk Score" tick={{ fontSize: 11, fill: "#888" }} />
              <Tooltip cursor={{ strokeDasharray: "3 3" }} content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const d = payload[0]?.payload;
                return (
                  <div style={{ background: "white", border: "1px solid #eee", borderRadius: 8, padding: "6px 10px", fontSize: 12 }}>
                    <p style={{ margin: 0 }}>Credit: <b>{d?.x}</b></p>
                    <p style={{ margin: 0 }}>Risk: <b>{d?.y}</b></p>
                    <p style={{ margin: 0, color: d?.defaulted ? C.coral : C.teal }}>
                      {d?.defaulted ? "⚠ Defaulted" : "✓ Active"}
                    </p>
                  </div>
                );
              }} />
              <Scatter data={scatterData.filter(d => !d.defaulted)} fill={C.purple} fillOpacity={0.4} name="Active" />
              <Scatter data={scatterData.filter(d => d.defaulted)} fill={C.coral} fillOpacity={0.7} name="Defaulted" />
            </ScatterChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
          <h3 style={{ margin: "0 0 4px", fontSize: 15, fontWeight: 600 }}>Missed Payments → Risk Escalation</h3>
          <p style={{ margin: "0 0 12px", fontSize: 12, color: "#888" }}>
            Each missed payment adds ~8–10 risk points on average
          </p>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={riskByMissed} margin={{ bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f5f5f5" />
              <XAxis dataKey="missed" tick={{ fontSize: 12, fill: "#888" }}
                label={{ value: "Missed Payments", position: "insideBottom", offset: -10, fontSize: 12, fill: "#888" }} />
              <YAxis tick={{ fontSize: 12, fill: "#888" }} domain={[0, 100]} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="avgRisk" name="Avg Risk Score" fill={C.coral} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={{ background: "white", borderRadius: 12, padding: 20, border: "1px solid #f0eff8" }}>
        <h3 style={{ margin: "0 0 12px", fontSize: 15, fontWeight: 600 }}>
          Default Rate by Credit Score Band
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 10 }}>
          {creditBuckets.map(b => (
            <div key={b.range} style={{
              background: b.defaultRate > 20 ? C.coralLight : b.defaultRate > 10 ? C.amberLight : C.tealLight,
              borderRadius: 10, padding: "14px 12px", textAlign: "center",
            }}>
              <p style={{ margin: "0 0 2px", fontSize: 11, color: "#666", fontWeight: 600 }}>{b.label}</p>
              <p style={{ margin: "0 0 4px", fontSize: 12, color: "#888" }}>{b.range}</p>
              <p style={{ margin: "0 0 2px", fontSize: 26, fontWeight: 700, color: b.defaultRate > 20 ? C.coralDark : b.defaultRate > 10 ? C.amberDark : C.tealDark }}>
                {b.defaultRate}%
              </p>
              <p style={{ margin: 0, fontSize: 11, color: "#888" }}>{b.count} customers</p>
            </div>
          ))}
        </div>
        <p style={{ margin: "12px 0 0", fontSize: 12, color: "#888" }}>
          <b>Key insight:</b> Customers with credit scores below 500 have 4× higher default rates. Immediate intervention recommended.
        </p>
      </div>
    </div>
  );
}
