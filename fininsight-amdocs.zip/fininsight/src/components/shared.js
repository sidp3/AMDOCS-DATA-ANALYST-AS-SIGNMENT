import React from "react";
import { Tooltip } from "recharts";

// ─── CUSTOM TOOLTIP ──────────────────────────────────────────────────────────
export const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "white", border: "1px solid #e5e7eb", borderRadius: 8,
      padding: "8px 12px", fontSize: 13,
      boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
    }}>
      <p style={{ fontWeight: 600, marginBottom: 4 }}>{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color, margin: "2px 0" }}>
          {p.name}:{" "}
          <b>{typeof p.value === "number" && p.value > 1000
            ? new Intl.NumberFormat("en-IN").format(p.value)
            : p.value}
          </b>
        </p>
      ))}
    </div>
  );
};

// ─── METRIC CARD ─────────────────────────────────────────────────────────────
export const MetricCard = ({ label, value, sub, color = "#7F77DD", icon }) => (
  <div style={{
    background: "white", borderRadius: 12, padding: "16px 20px",
    border: "1px solid #f0eff8", boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
    minWidth: 0,
  }}>
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
      <div>
        <p style={{ fontSize: 12, color: "#888", margin: 0, letterSpacing: "0.4px", textTransform: "uppercase", fontWeight: 600 }}>
          {label}
        </p>
        <p style={{ fontSize: 26, fontWeight: 700, margin: "4px 0 2px", color: "#1a1a2e" }}>
          {value}
        </p>
        {sub && (
          <p style={{ fontSize: 12, color, margin: 0, fontWeight: 500 }}>{sub}</p>
        )}
      </div>
      {icon && <span style={{ fontSize: 24, opacity: 0.7 }}>{icon}</span>}
    </div>
  </div>
);

// ─── FILTER BAR ───────────────────────────────────────────────────────────────
export const FilterBar = ({ filters, setFilters, total }) => (
  <div style={{
    display: "flex", gap: 10, alignItems: "center", marginBottom: 20,
    padding: "10px 16px", background: "white", borderRadius: 10,
    border: "1px solid #f0eff8",
  }}>
    <span style={{ fontSize: 12, color: "#888", fontWeight: 600, marginRight: 4 }}>FILTERS:</span>
    {[
      { key: "region", label: "Region", opts: ["All","North","South","East","West","Central"] },
      { key: "segment", label: "Segment", opts: ["All","High Value","Mid Value","Low Value"] },
    ].map(f => (
      <div key={f.key} style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <label style={{ fontSize: 12, color: "#666" }}>{f.label}:</label>
        <select
          value={filters[f.key]}
          onChange={e => setFilters(prev => ({ ...prev, [f.key]: e.target.value }))}
          style={{ fontSize: 13, padding: "4px 8px", borderRadius: 6, border: "1px solid #e5e7eb", background: "white" }}
        >
          {f.opts.map(o => <option key={o}>{o}</option>)}
        </select>
      </div>
    ))}
    <span style={{ marginLeft: "auto", fontSize: 12, color: "#aaa" }}>
      Showing {total} / 500 customers
    </span>
  </div>
);
